
import java.awt.Color;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableModel;
import org.jfree.data.category.DefaultCategoryDataset;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author glenncarvalho
 */
public class SALE_WINDOW extends javax.swing.JFrame {

    /**
     * Creates new form SALE_WINDOW
     */
    public SALE_WINDOW() {
        initComponents();
        
        // set border to the jPanel title
        Border panel_title_border = BorderFactory.createMatteBorder(0, 0, 3, 0, new Color (255,10,0));
        jPanel_Title .setBorder(panel_title_border);
        
        // set border to the jbuttons
        Border button_border = BorderFactory.createMatteBorder(3, 3, 3, 3, new Color (255, 255, 255));
        jButton_Add_Sale.setBorder(button_border);
        jButton_Edit_Sale.setBorder(button_border); 
        jButton_Remove_Sale.setBorder(button_border);
        
        // populate the jTable properties with the property ID, owner ID, price
        fillJtableProperties();
        
        // populate the jTable clients with the client ID, first name, last name
        fillJtableClients();
        
        // populate the jTable sales
        fillJtableSales();
        
        // change the jTable row height
        jTable_Clients.setRowHeight(40);
        jTable_Properties.setRowHeight(40);
        jTable_Sales.setRowHeight(40);

        // change the jTable selection background
        jTable_Clients.setSelectionBackground(new Color (27, 150, 77));
        jTable_Properties.setSelectionBackground(new Color (20,120,10));
        jTable_Sales.setSelectionBackground(new Color (0,70,0));

    }
    
    public void fillJtableProperties()
    {
        P_PROPERTY property = new P_PROPERTY ();
        ArrayList<P_PROPERTY> propertyList = property.propertiesList();
        
        // the jTable columns
        String [] colNames = {"ID", "Owner ID", "Price"};
        
        // the jTable row
        // clientList.size() = the size of the arrayList
        // 6 = the number of columns
        
        Object [][] rows = new Object [propertyList.size()][3];
        
        // add data from the list to the rows
        for (int i=0; i<propertyList.size(); i++)
        {
            rows [i][0]=propertyList.get(i).getId();
            rows [i][1]=propertyList.get(i).getOwnerId();
            rows [i][2 ]=propertyList.get(i).getPrice();

        }
        
        DefaultTableModel model = new DefaultTableModel (rows, colNames);
        jTable_Properties.setModel(model);
    }

    public void fillJtableClients()
    {
           P_CLIENT client = new P_CLIENT ();
        ArrayList<P_CLIENT> clientList = client.clientsList();
        
        // the jTable columns
        String [] colNames = {"ID", "First Name", "Last Name"};
        
        // the jTable row
        // clientList.size() = the size of the arrayList
        // 6 = the number of columns
        
        Object [][] rows = new Object [clientList.size()][3];
        
        // add data from the list to the rows
        for (int i=0; i<clientList.size(); i++)
        {
            rows [i][0]=clientList.get(i).getId();
            rows [i][1]=clientList.get(i).getFname();
            rows [i][2]=clientList.get(i).getLname();
        }
        
        DefaultTableModel model = new DefaultTableModel (rows, colNames);
        jTable_Clients.setModel(model);
    }
    
     public void fillJtableSales()
    {
        P_SALE sale = new P_SALE ();
        ArrayList<P_SALE> salesList = sale.salesList();
        
        // the jTable columns
        String [] colNames = {"ID", "Property", "Client", "Price", "Date"};
        
        // the jTable row
        // clientList.size() = the size of the arrayList
        // 5 = the number of columns
        
        Object [][] rows = new Object [salesList.size()][5];
        
        // add data from the list to the rows
        for (int i=0; i<salesList.size(); i++)
        {
            rows [i][0]=salesList.get(i).getId();
            rows [i][1]=salesList.get(i).getPropertyId();
            rows [i][2]=salesList.get(i).getClientId();
            rows [i][3]=salesList.get(i).getFinalPrice();
            rows [i][4]=salesList.get(i).getSellingDate();
        }
        
        DefaultTableModel model = new DefaultTableModel (rows, colNames);
        jTable_Sales.setModel(model);
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel_Title = new javax.swing.JPanel();
        jLabel_Title = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextField_Id = new javax.swing.JTextField();
        jButton_Remove_Sale = new javax.swing.JButton();
        jButton_Add_Sale = new javax.swing.JButton();
        jButton_Edit_Sale = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jTextField_ClientId = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextField_FinalPrice = new javax.swing.JTextField();
        jLabel_Date = new javax.swing.JLabel();
        jTextField_PropertyId = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable_Properties = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable_Clients = new javax.swing.JTable();
        jDateChooser_SaleDate = new com.toedter.calendar.JDateChooser();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable_Sales = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        jButton_Refresh_Clients_Table = new javax.swing.JButton();
        jButton_Refresh_Sales_Table = new javax.swing.JButton();
        jButton_Add_Client = new javax.swing.JButton();
        jButton_Refresh_Properties_Table = new javax.swing.JButton();
        jButton_Add_Property = new javax.swing.JButton();
        jButton_bar_chart = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 102, 51));

        jPanel_Title.setBackground(new java.awt.Color(255, 51, 0));

        jLabel_Title.setBackground(new java.awt.Color(153, 153, 153));
        jLabel_Title.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        jLabel_Title.setForeground(new java.awt.Color(255, 255, 255));
        jLabel_Title.setText("Sales");

        javax.swing.GroupLayout jPanel_TitleLayout = new javax.swing.GroupLayout(jPanel_Title);
        jPanel_Title.setLayout(jPanel_TitleLayout);
        jPanel_TitleLayout.setHorizontalGroup(
            jPanel_TitleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel_TitleLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel_Title, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(416, 416, 416))
        );
        jPanel_TitleLayout.setVerticalGroup(
            jPanel_TitleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel_TitleLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel_Title, javax.swing.GroupLayout.DEFAULT_SIZE, 43, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel1.setText("ID:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel3.setText("Property ID:");

        jTextField_Id.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jTextField_Id.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField_IdKeyReleased(evt);
            }
        });

        jButton_Remove_Sale.setBackground(new java.awt.Color(255, 51, 51));
        jButton_Remove_Sale.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton_Remove_Sale.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Remove_Sale.setText("Remove");
        jButton_Remove_Sale.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Remove_Sale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_Remove_SaleActionPerformed(evt);
            }
        });

        jButton_Add_Sale.setBackground(new java.awt.Color(0, 153, 51));
        jButton_Add_Sale.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton_Add_Sale.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Add_Sale.setText("Add");
        jButton_Add_Sale.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Add_Sale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_Add_SaleActionPerformed(evt);
            }
        });

        jButton_Edit_Sale.setBackground(new java.awt.Color(0, 153, 255));
        jButton_Edit_Sale.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton_Edit_Sale.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Edit_Sale.setText("Edit");
        jButton_Edit_Sale.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Edit_Sale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_Edit_SaleActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel4.setText("Client ID:");

        jTextField_ClientId.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jTextField_ClientId.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField_ClientIdKeyReleased(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel5.setText("Final Price:");

        jTextField_FinalPrice.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jTextField_FinalPrice.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField_FinalPriceKeyReleased(evt);
            }
        });

        jLabel_Date.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel_Date.setText("Date:");

        jTextField_PropertyId.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jTextField_PropertyId.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField_PropertyIdKeyReleased(evt);
            }
        });

        jTable_Properties.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTable_Properties.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_PropertiesMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable_Properties);

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel7.setText("Properties List:");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel8.setText("Clients List:");

        jTable_Clients.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTable_Clients.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_ClientsMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable_Clients);

        jDateChooser_SaleDate.setDateFormatString("dd/MM/yyyy");
        jDateChooser_SaleDate.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jTable_Sales.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jTable_Sales.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable_SalesMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(jTable_Sales);

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        jLabel9.setText("Sales List:");

        jButton_Refresh_Clients_Table.setBackground(new java.awt.Color(255, 204, 0));
        jButton_Refresh_Clients_Table.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton_Refresh_Clients_Table.setText("Refresh");
        jButton_Refresh_Clients_Table.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Refresh_Clients_Table.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_Refresh_Clients_TableActionPerformed(evt);
            }
        });

        jButton_Refresh_Sales_Table.setBackground(new java.awt.Color(255, 204, 0));
        jButton_Refresh_Sales_Table.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton_Refresh_Sales_Table.setText("Refresh");
        jButton_Refresh_Sales_Table.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Refresh_Sales_Table.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_Refresh_Sales_TableActionPerformed(evt);
            }
        });

        jButton_Add_Client.setBackground(new java.awt.Color(0, 153, 51));
        jButton_Add_Client.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton_Add_Client.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Add_Client.setText("Add New Client");
        jButton_Add_Client.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Add_Client.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_Add_ClientActionPerformed(evt);
            }
        });

        jButton_Refresh_Properties_Table.setBackground(new java.awt.Color(255, 204, 0));
        jButton_Refresh_Properties_Table.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton_Refresh_Properties_Table.setText("Refresh");
        jButton_Refresh_Properties_Table.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Refresh_Properties_Table.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_Refresh_Properties_TableActionPerformed(evt);
            }
        });

        jButton_Add_Property.setBackground(new java.awt.Color(0, 153, 51));
        jButton_Add_Property.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton_Add_Property.setForeground(new java.awt.Color(255, 255, 255));
        jButton_Add_Property.setText("Add New Property");
        jButton_Add_Property.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_Add_Property.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_Add_PropertyActionPerformed(evt);
            }
        });

        jButton_bar_chart.setBackground(new java.awt.Color(0, 153, 51));
        jButton_bar_chart.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton_bar_chart.setForeground(new java.awt.Color(255, 255, 255));
        jButton_bar_chart.setText("Generate Bar Chart");
        jButton_bar_chart.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton_bar_chart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton_bar_chartActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel_Title, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGap(78, 78, 78)
                        .addComponent(jLabel_Date)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jDateChooser_SaleDate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField_PropertyId)
                            .addComponent(jTextField_ClientId)
                            .addComponent(jTextField_FinalPrice)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                        .addGap(99, 99, 99)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField_Id, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton_Add_Sale, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton_Edit_Sale, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton_Remove_Sale, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(40, 40, 40)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton_Refresh_Sales_Table, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                    .addComponent(jButton_bar_chart, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jButton_Add_Client, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                            .addComponent(jButton_Refresh_Clients_Table, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jButton_Add_Property, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton_Refresh_Properties_Table, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel_Title, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jTextField_Id, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jTextField_PropertyId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jTextField_ClientId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField_FinalPrice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5))
                        .addGap(9, 9, 9)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jDateChooser_SaleDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel_Date))
                        .addGap(38, 38, 38)
                        .addComponent(jButton_Add_Sale, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton_Edit_Sale, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton_Remove_Sale, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 396, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 396, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 396, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jButton_Refresh_Clients_Table, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButton_Refresh_Sales_Table, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jButton_Add_Client, javax.swing.GroupLayout.DEFAULT_SIZE, 42, Short.MAX_VALUE)
                                    .addComponent(jButton_bar_chart, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jButton_Refresh_Properties_Table, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton_Add_Property, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton_Remove_SaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_Remove_SaleActionPerformed

        // remove the selected sale 
        try 
            {
            int id = Integer.valueOf(jTextField_Id.getText());

            if (new P_SALE().deleteSale(id))
            {
                JOptionPane.showMessageDialog(null, "Sale data has been deleted.", "Deleted Sale", 1);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Sale not deleted.", "Delete Sale", 2);
            }
            }
        catch (Exception ex)
        {
            JOptionPane.showMessageDialog(null, "Select the Sale ID", "Delete Sale Error", 2);
        }
    }//GEN-LAST:event_jButton_Remove_SaleActionPerformed

    private void jButton_Add_SaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_Add_SaleActionPerformed

        // add a new sale
        // int id = Integer.valueOf(jTextField_Id.getText());
        try 
        {
           int propertyId = Integer.valueOf (jTextField_PropertyId.getText());
            int clientId = Integer.valueOf (jTextField_ClientId.getText());
            String finalPrice = jTextField_FinalPrice.getText();
            SimpleDateFormat dateFormat = new SimpleDateFormat ("yyyy-MM-dd");
            String sellingDate = dateFormat.format (jDateChooser_SaleDate.getDate());

            P_SALE sale = new P_SALE (0,propertyId, clientId, finalPrice, sellingDate);

            if (new P_SALE().addNewSale(sale))
            {
                JOptionPane.showMessageDialog(null, "New sale created and added.", "Add Sale", 1);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Sale not created", "Add Sale", 2);
            } 
            } 
        catch (Exception ex)
        {
           JOptionPane.showMessageDialog(null, "Select the Property ID, Client ID, Sale Date", "Add Sale Error", 2);
        }
        
       
    }//GEN-LAST:event_jButton_Add_SaleActionPerformed

    private void jTable_PropertiesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_PropertiesMouseClicked

        int selectedRowIndex = jTable_Properties.getSelectedRow();
        jTextField_PropertyId.setText(jTable_Properties.getValueAt(selectedRowIndex, 0).toString());
        jTextField_FinalPrice.setText(jTable_Properties.getValueAt(selectedRowIndex, 2).toString());
    }//GEN-LAST:event_jTable_PropertiesMouseClicked

    private void jTable_ClientsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_ClientsMouseClicked
       
        int selectedRowIndex = jTable_Clients.getSelectedRow();
        jTextField_ClientId.setText(jTable_Clients.getValueAt(selectedRowIndex, 0).toString());
    }//GEN-LAST:event_jTable_ClientsMouseClicked

    private void jTable_SalesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable_SalesMouseClicked
       
        // display the selected sale data
        int selectedRowIndex = jTable_Sales.getSelectedRow();
        jTextField_Id.setText(jTable_Sales.getValueAt(selectedRowIndex, 0).toString());
        jTextField_PropertyId.setText(jTable_Sales.getValueAt(selectedRowIndex, 1).toString());
        jTextField_ClientId.setText(jTable_Sales.getValueAt(selectedRowIndex, 2).toString());
        jTextField_FinalPrice.setText(jTable_Sales.getValueAt(selectedRowIndex, 3).toString());

        // display the date in jDateChooser
        Date saleDate;
        try {
            saleDate = new SimpleDateFormat("yyyy-MM-dd").parse(jTable_Sales.getValueAt(selectedRowIndex, 4).toString());
            jDateChooser_SaleDate.setDate(saleDate);

        } catch (ParseException ex) {
            Logger.getLogger(SALE_WINDOW.class.getName()).log(Level.SEVERE, null, ex);
        } 
    }//GEN-LAST:event_jTable_SalesMouseClicked

    private void jButton_Refresh_Clients_TableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_Refresh_Clients_TableActionPerformed
        
        // refresh the jTable clients
        fillJtableClients();
        
    }//GEN-LAST:event_jButton_Refresh_Clients_TableActionPerformed

    private void jButton_Edit_SaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_Edit_SaleActionPerformed

        // edit the selected sale
        
        try 
        {
            int id = Integer.valueOf(jTextField_Id.getText());
            int propertyId = Integer.valueOf (jTextField_PropertyId.getText());
            int clientId = Integer.valueOf (jTextField_ClientId.getText());
            String finalPrice = jTextField_FinalPrice.getText();
            SimpleDateFormat dateFormat = new SimpleDateFormat ("yyyy-MM-dd");
            String sellingate = dateFormat.format (jDateChooser_SaleDate.getDate());

            P_SALE sale = new P_SALE (id, propertyId, clientId, finalPrice, sellingate);

            if (new P_SALE().editSale(sale))
            {
                JOptionPane.showMessageDialog(null, "Sale data has been updated.", "Edit Sale", 1);
            }
            else
            {
                JOptionPane.showMessageDialog(null, "Sale not updated", "Edit Sale", 2);
            }
        }
        catch (Exception ex)
            {
                JOptionPane.showMessageDialog(null, "Select the Sale ID, Client ID, Sale Date", "Edit Sale Error", 2);
            }
    }//GEN-LAST:event_jButton_Edit_SaleActionPerformed

    private void jButton_Refresh_Sales_TableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_Refresh_Sales_TableActionPerformed
        // refresh the jTable sales
        fillJtableSales();
    }//GEN-LAST:event_jButton_Refresh_Sales_TableActionPerformed

    private void jButton_Add_ClientActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_Add_ClientActionPerformed
        
        // open the client form
        CLIENT_WINDOW clientForm = new CLIENT_WINDOW();
        clientForm.setVisible(true);
        clientForm.pack();
        clientForm.setLocationRelativeTo(null);
        clientForm.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }//GEN-LAST:event_jButton_Add_ClientActionPerformed

    private void jButton_Refresh_Properties_TableActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_Refresh_Properties_TableActionPerformed
        
        // refresh the jTable properties
        fillJtableProperties();
        
    }//GEN-LAST:event_jButton_Refresh_Properties_TableActionPerformed

    private void jButton_Add_PropertyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_Add_PropertyActionPerformed

        
        // open the property form
        PROPERTY_WINDOW propertyform = new PROPERTY_WINDOW();
        propertyform.setVisible(true);
        propertyform.pack();
        propertyform.setLocationRelativeTo(null);
        propertyform.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }//GEN-LAST:event_jButton_Add_PropertyActionPerformed

    private void jButton_bar_chartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton_bar_chartActionPerformed
        
        DefaultCategoryDataset dataset = new DefaultCategoryDataset ();
        //dataset.setValue(WIDTH,file, file);
        
    }//GEN-LAST:event_jButton_bar_chartActionPerformed

    private void jTextField_FinalPriceKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField_FinalPriceKeyReleased
        int x;
        try {
            x = Integer.parseInt(jTextField_FinalPrice.getText());
        } catch (NumberFormatException nfe) {
            jTextField_FinalPrice.setText("");
        }
    }//GEN-LAST:event_jTextField_FinalPriceKeyReleased

    private void jTextField_IdKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField_IdKeyReleased
        int x;
        try {
            x = Integer.parseInt(jTextField_Id.getText());
        } catch (NumberFormatException nfe) {
            jTextField_Id.setText("");
        }
    }//GEN-LAST:event_jTextField_IdKeyReleased

    private void jTextField_PropertyIdKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField_PropertyIdKeyReleased
        
        int x;
        try {
            x = Integer.parseInt(jTextField_PropertyId.getText());
        } catch (NumberFormatException nfe) {
            jTextField_PropertyId.setText("");
        }
        
    }//GEN-LAST:event_jTextField_PropertyIdKeyReleased

    private void jTextField_ClientIdKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField_ClientIdKeyReleased
        int x;
        try {
            x = Integer.parseInt(jTextField_ClientId.getText());
        } catch (NumberFormatException nfe) {
            jTextField_ClientId.setText("");
        }
    }//GEN-LAST:event_jTextField_ClientIdKeyReleased

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SALE_WINDOW.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SALE_WINDOW.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SALE_WINDOW.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SALE_WINDOW.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SALE_WINDOW().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton_Add_Client;
    private javax.swing.JButton jButton_Add_Property;
    private javax.swing.JButton jButton_Add_Sale;
    private javax.swing.JButton jButton_Edit_Sale;
    private javax.swing.JButton jButton_Refresh_Clients_Table;
    private javax.swing.JButton jButton_Refresh_Properties_Table;
    private javax.swing.JButton jButton_Refresh_Sales_Table;
    private javax.swing.JButton jButton_Remove_Sale;
    private javax.swing.JButton jButton_bar_chart;
    private com.toedter.calendar.JDateChooser jDateChooser_SaleDate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel_Date;
    private javax.swing.JLabel jLabel_Title;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel_Title;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable_Clients;
    private javax.swing.JTable jTable_Properties;
    private javax.swing.JTable jTable_Sales;
    private javax.swing.JTextField jTextField_ClientId;
    private javax.swing.JTextField jTextField_FinalPrice;
    private javax.swing.JTextField jTextField_Id;
    private javax.swing.JTextField jTextField_PropertyId;
    // End of variables declaration//GEN-END:variables
}
